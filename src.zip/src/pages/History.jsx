import React from 'react'

function History() {
  return (
    <div>History</div>
  )
}

export default History