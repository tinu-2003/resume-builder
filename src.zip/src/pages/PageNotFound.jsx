import { Margin } from '@mui/icons-material'
import React from 'react'

function PageNotFound() {
  return (
    <>
    <div id='pnf-head'>
    <h2>Look Like You're Lost</h2>
    <p>The page ypu are look  for is not available</p>
    <button>Go Back Home</button>
   </div>
   <div> <img src="https://shop.sesto.ir/wp-content/uploads/2022/10/funny-404-error-page-design.gif" alt="404-img" width={'100%'} height={"800px"} />
   
   </div>

   
    
    </>
  )
}

export default PageNotFound